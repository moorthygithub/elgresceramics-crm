//ace
const BASE_URL = "https://test.dfclogistics.online/public";

export default BASE_URL;
